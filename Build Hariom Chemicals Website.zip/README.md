
  # Build Hariom Chemicals Website

  This is a code bundle for Build Hariom Chemicals Website. The original project is available at https://www.figma.com/design/oNcLIO4pn8I7oDgCUnz1gf/Build-Hariom-Chemicals-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  